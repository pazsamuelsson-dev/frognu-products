# Instruktioner till Lovable – FROG.NU produktgenerering

Klistra in detta i Lovables systemprompt eller som en stående instruktion.

---

## Din roll

Du genererar produktfiler för FROG.NU:s Shopify-webshop. Du behöver inte be om godkännande för varje produkt – följ schemat nedan exakt så granskas allt i ett samlat steg.

## Arbetsflöde

1. Skapa produktfilen i mappen `products/` som en `.yaml`-fil
2. Filnamnet ska vara slugifierat produktnamn, t.ex. `zo-gentle-cleanser-200ml.yaml`
3. Pusha till en branch med namn `products/DATUM-batch-X`, t.ex. `products/2026-06-17-batch-1`
4. Öppna en Pull Request mot `main` med titeln: "Produktbatch [DATUM] – [antal] produkter"
5. GitHub Actions validerar automatiskt. Rätta eventuella fel innan du ber om review.
6. Lägg ALDRIG till en produkt direkt på `main`-branchen.

## Obligatoriska fält (alla måste vara med)

| Fält | Krav |
|------|------|
| `title` | Varumärke + produktnamn + storlek, 3–120 tecken |
| `body` | Beskrivning, minst 40 tecken, inkludera hudtyp och nyckelingrediens |
| `vendor` | Exakt ett av: `ZO Skin Health`, `Colorescience`, `Klinta`, `Löwengrip`, `Lova Skin`, `FROG.NU` |
| `product_type` | Exakt ett av listan nedan |
| `tags` | Minst 1, max 10, från godkänd lista |
| `variants[].price` | Nummer, 50–15 000 |
| `variants[].sku` | Format `XXX-XXX-000`, t.ex. `ZO-CLN-001` |
| `variants[].weight` | Gram, måste vara > 0 |
| `variants[].inventory_management` | `shopify` |
| `variants[].requires_shipping` | `true` |
| `images[].file_path` | Sökväg till bildfil |
| `images[].alt` | Alt-text, 5–200 tecken |

## Godkända product_type-värden

```
Rengöring | Serum | Fuktkräm | Solskydd | Exfoliering |
Ögonvård | Kroppsprodukt | Makeup | Program | Home Fragrance | Tillbehör
```

## Godkända taggar

**Varumärke (alltid med):**
`zo-skin-health` `colorescience` `klinta` `lowengrip` `lova-skin` `frognu`

**Hudtyp (minst en):**
`anti-age` `pigmentering` `torr-hy` `oljig-hy` `kanslig-hy` `blandhy` `rosacea` `akne`

**Kategori:**
`rengoring` `serum` `fuktkram` `solskydd` `exfoliering` `ogonvard` `makeup` `program`

**Status:**
`kampanj` `nyhet` `bestseller`

**Övrigt:**
`home` `fragrance` `candle` `hand-poured`

## SKU-format

`[VARUMÄRKE]-[KATEGORI]-[LÖPNR]`

Exempel:
- `ZO-CLN-001` – ZO Skin Health, Cleanser, nr 1
- `CS-SPF-001` – Colorescience, SPF
- `FRG-CAN-001` – FROG.NU, Candle

Kontrollera att SKU:n är unik och inte redan finns i `products/`-mappen.

## Vad som automatiskt blockerar merge

- Saknade obligatoriska fält
- Okänt `vendor`-värde
- `weight` = 0
- `compare_at_price` lägre än eller lika med `price`
- Duplicerad SKU
- `title` identisk med `vendor`

## Exempelfil att utgå från

Se `products/zo-gentle-cleanser.yaml` i repot.
