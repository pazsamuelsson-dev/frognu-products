#!/usr/bin/env node
/**
 * FROG.NU Produktvalidering
 * Kör: node validate.js products/
 *      node validate.js products/ny-produkt.yaml
 */

const fs = require("fs");
const path = require("path");

let Ajv, yaml;
try { Ajv = require("ajv"); } catch { die("Saknar ajv – kör: npm install ajv"); }
try { yaml = require("js-yaml"); } catch { die("Saknar js-yaml – kör: npm install js-yaml"); }

const ajv = new Ajv({ allErrors: true, strict: false });
const schema = JSON.parse(fs.readFileSync(path.join(__dirname, "../schemas/product-schema.json"), "utf8"));
const validate = ajv.compile(schema);

const target = process.argv[2];
if (!target) die("Ange en fil eller mapp: node validate.js products/");

const files = fs.statSync(target).isDirectory()
  ? fs.readdirSync(target)
      .filter(f => f.endsWith(".yaml") || f.endsWith(".yml"))
      .map(f => path.join(target, f))
  : [target];

if (files.length === 0) die("Inga YAML-filer hittades i " + target);

let passed = 0;
let failed = 0;
const errors = [];

for (const file of files) {
  const raw = fs.readFileSync(file, "utf8");
  let product;
  try {
    product = yaml.load(raw);
  } catch (e) {
    failed++;
    errors.push({ file, issues: ["YAML-syntaxfel: " + e.message] });
    continue;
  }

  const issues = [];

  // JSON Schema-validering
  const valid = validate(product);
  if (!valid) {
    for (const err of validate.errors) {
      const loc = err.instancePath || "(rot)";
      issues.push(`${loc}: ${err.message}`);
    }
  }

  // Extra regler som JSON Schema inte hanterar smidigt

  // compare_at_price måste vara högre än price
  if (product.variants) {
    for (let i = 0; i < product.variants.length; i++) {
      const v = product.variants[i];
      if (v.compare_at_price && v.compare_at_price <= v.price) {
        issues.push(
          `variants[${i}]: compare_at_price (${v.compare_at_price}) måste vara högre än price (${v.price})`
        );
      }
    }
  }

  // SKU-dubbletter inom filen
  if (product.variants) {
    const skus = product.variants.map(v => v.sku).filter(Boolean);
    const dupes = skus.filter((s, i) => skus.indexOf(s) !== i);
    if (dupes.length > 0) {
      issues.push(`Duplicerade SKU:er: ${dupes.join(", ")}`);
    }
  }

  // Bildfil existens-kontroll (om lokal sökväg)
  if (product.images) {
    for (const img of product.images) {
      if (img.file_path && img.file_path.startsWith("src/")) {
        const imgPath = path.resolve(path.dirname(file), "../..", img.file_path);
        if (!fs.existsSync(imgPath)) {
          issues.push(`Bildfil saknas: ${img.file_path}`);
        }
      }
    }
  }

  // Titel får inte vara bara varumärkesnamn
  if (product.title && product.vendor && product.title.trim() === product.vendor.trim()) {
    issues.push("title får inte vara identisk med vendor – lägg till produktnamn");
  }

  if (issues.length === 0) {
    passed++;
    console.log(`✓  ${path.basename(file)}  →  ${product.title}`);
  } else {
    failed++;
    errors.push({ file: path.basename(file), title: product.title || "?", issues });
  }
}

// Sammanfattning
console.log(`\n${"─".repeat(50)}`);
console.log(`Resultat: ${passed} godkända, ${failed} med fel\n`);

if (errors.length > 0) {
  for (const e of errors) {
    console.log(`✗  ${e.file}${e.title ? "  (" + e.title + ")" : ""}`);
    for (const issue of e.issues) {
      console.log(`   • ${issue}`);
    }
    console.log("");
  }
  console.log("Rätta felen och kör validering igen innan du pushar till GitHub.\n");
  process.exit(1);
} else {
  console.log("Alla produkter godkända – redo att pusha till GitHub.\n");
  process.exit(0);
}

function die(msg) { console.error("FEL: " + msg); process.exit(1); }
